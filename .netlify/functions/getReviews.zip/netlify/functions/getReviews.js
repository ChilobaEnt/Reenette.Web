var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var getReviews_exports = {};
__export(getReviews_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(getReviews_exports);
var import_pg = require("pg");
async function handler(event) {
  const tourId = event.queryStringParameters?.tour_id;
  if (!tourId) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: "Missing required query parameter: tour_id" })
    };
  }
  const connectionString = process.env.NEON_DATABASE_URL;
  if (!connectionString) {
    console.error("NEON_DATABASE_URL is not set");
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Database configuration missing" })
    };
  }
  const client = new import_pg.Client({
    connectionString,
    statement_timeout: 5e3
  });
  try {
    await client.connect();
    const result = await client.query(
      "SELECT id, tour_id, user_id, rating, comment, created_at FROM reviews WHERE tour_id = $1 ORDER BY created_at DESC",
      [tourId]
    );
    return {
      statusCode: 200,
      body: JSON.stringify(result.rows)
    };
  } catch (err) {
    console.error("getReviews error:", err && err.message ? err.message : err);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Failed to fetch reviews", details: err && err.message ? err.message : void 0 })
    };
  } finally {
    try {
      await client.end();
    } catch (e) {
      console.warn("Error closing DB client", e && e.message ? e.message : e);
    }
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
