var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var postNewsletter_exports = {};
__export(postNewsletter_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(postNewsletter_exports);
var import_pg = require("pg");
async function handler(event) {
  try {
    const payload = event.body ? JSON.parse(event.body) : {};
    const { email } = payload;
    if (!email) {
      return { statusCode: 400, body: JSON.stringify({ error: "Email is required" }) };
    }
    try {
      const client = new import_pg.Client({ connectionString: process.env.NEON_DATABASE_URL });
      await client.connect();
      await client.query(
        "INSERT INTO newsletter_subscriptions (email, created_at) VALUES ($1, NOW())",
        [email]
      );
      await client.end();
    } catch (dbErr) {
      console.error("DB insert failed (newsletter):", dbErr);
    }
    if (process.env.SENDGRID_API_KEY) {
      let sgMail = null;
      try {
        sgMail = (await import("@sendgrid/mail")).default;
        sgMail.setApiKey(process.env.SENDGRID_API_KEY);
      } catch (importErr) {
        console.error("SendGrid module not available or failed to load:", importErr);
        sgMail = null;
      }
      if (sgMail) {
        const to = process.env.NOTIFY_EMAIL || "info@reenette.com";
        const from = process.env.FROM_EMAIL || "no-reply@reenette.com";
        const subject = `New newsletter subscription: ${email}`;
        const html = `<p>New subscriber: <strong>${email}</strong></p>`;
        try {
          await sgMail.send({ to, from, subject, html });
        } catch (mailErr) {
          console.error("SendGrid error (newsletter):", mailErr);
        }
      } else {
        console.warn("SENDGRID_API_KEY is set but @sendgrid/mail could not be loaded; skipping email send.");
      }
    }
    try {
      const formSubmitEndpoint = `https://formsubmit.co/${process.env.NOTIFY_EMAIL || "info@reenette.com"}`;
      const params = new URLSearchParams();
      params.append("Client", email);
      params.append("message", "Newsletter subscription");
      const res = await fetch(formSubmitEndpoint, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: params.toString()
      });
      if (!res.ok) console.error("FormSubmit forward failed (newsletter):", res.status);
    } catch (forwardErr) {
      console.error("FormSubmit forward error (newsletter):", forwardErr);
    }
    return { statusCode: 201, body: JSON.stringify({ success: true }) };
  } catch (err) {
    console.error(err);
    return { statusCode: 500, body: JSON.stringify({ error: "Failed to subscribe" }) };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
