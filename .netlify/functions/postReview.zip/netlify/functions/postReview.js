var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var postReview_exports = {};
__export(postReview_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(postReview_exports);
var import_pg = require("pg");
async function handler(event) {
  try {
    const { tour_id, user_id, rating, comment } = JSON.parse(event.body || "{}");
    const client = new import_pg.Client({ connectionString: process.env.NEON_DATABASE_URL });
    await client.connect();
    await client.query(
      "INSERT INTO reviews (tour_id, user_id, rating, comment) VALUES ($1, $2, $3, $4)",
      [tour_id, user_id || null, rating, comment || null]
    );
    await client.end();
    return {
      statusCode: 201,
      body: JSON.stringify({ success: true })
    };
  } catch (err) {
    console.error(err);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Failed to submit review" })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
