var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var postContact_exports = {};
__export(postContact_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(postContact_exports);
var import_pg = require("pg");
var import_mail = __toESM(require("@sendgrid/mail"), 1);
import_mail.default.setApiKey(process.env.SENDGRID_API_KEY || "");
async function handler(event) {
  try {
    const payload = event.body ? JSON.parse(event.body) : {};
    const { name, Client: email, destination, message } = payload;
    const client = new import_pg.Client({ connectionString: process.env.NEON_DATABASE_URL });
    await client.connect();
    await client.query(
      "INSERT INTO contact_messages (name, email, destination, message) VALUES ($1, $2, $3, $4)",
      [name || null, email || null, destination || null, message || null]
    );
    await client.end();
    if (process.env.SENDGRID_API_KEY) {
      const to = process.env.NOTIFY_EMAIL || "info@reenette.com";
      const from = process.env.FROM_EMAIL || "no-reply@reenette.com";
      const subject = `New contact message from ${name || "Website visitor"}`;
      const html = `
        <p><strong>Name:</strong> ${name || ""}</p>
        <p><strong>Email:</strong> ${email || ""}</p>
        <p><strong>Destination:</strong> ${destination || ""}</p>
        <p><strong>Message:</strong><br/>${message || ""}</p>
      `;
      try {
        await import_mail.default.send({ to, from, subject, html });
      } catch (mailErr) {
        console.error("SendGrid error (contact):", mailErr);
      }
    }
    try {
      const formSubmitEndpoint = `https://formsubmit.co/${process.env.NOTIFY_EMAIL || "info@reenette.com"}`;
      const params = new URLSearchParams();
      params.append("name", name || "");
      params.append("Client", email || "");
      params.append("destination", destination || "");
      params.append("message", message || "");
      const res = await fetch(formSubmitEndpoint, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: params.toString()
      });
      if (!res.ok) console.error("FormSubmit forward failed (contact):", res.status);
    } catch (forwardErr) {
      console.error("FormSubmit forward error (contact):", forwardErr);
    }
    return { statusCode: 201, body: JSON.stringify({ success: true }) };
  } catch (err) {
    console.error(err);
    return { statusCode: 500, body: JSON.stringify({ error: "Failed to save contact message" }) };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
